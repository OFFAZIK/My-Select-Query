# Welcome to My Select Query
welcome qwasar

## Task
What is the problem? And where is the challenge?
the challenge was in the beginning and i did it
## Description
How have you solved the problem?
I looked for information on the Internet
## Installation
How to install your project? npm install? make? make re?
mplement a where method which will take 2 arguments: column_name and value.
## Usage
How does it work?
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
