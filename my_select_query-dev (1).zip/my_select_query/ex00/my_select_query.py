class MySelectQuery():
    def __init__(self, csv_content):
        self.csv_content = csv_content
    def where(self, column_name, criteria):
        return [i for i in self.csv_content.split("\n") if criteria in i]